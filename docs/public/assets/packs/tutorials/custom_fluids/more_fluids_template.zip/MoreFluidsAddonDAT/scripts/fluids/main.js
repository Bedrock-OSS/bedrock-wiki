import * as mc from "@minecraft/server"

let fluidsIDs = [
"fluids:fluid_template",
"fluids:fluid_template_down",
"fluids:fluid_template1",
"fluids:fluid_template2",
"fluids:fluid_template3"
]

mc.world.events.tick.subscribe(() => {
    const players = Array.from(mc.world.getPlayers())
    for (let p = 0; p < players.length; p++) {
        for (let i = 0; i < fluidsIDs.length; i++) {
            if (mc.world.getDimension(players[p].dimension.id).getBlock(new mc.BlockLocation(Math.floor(players[p].location.x), Math.floor(players[p].location.y+1), Math.floor(players[p].location.z))).typeId == fluidsIDs[i]) {
                if (!players[p].isSneaking) {
                    players[p].addEffect(mc.MinecraftEffectTypes.levitation, 4, 1, false)
                }
                players[p].addEffect(mc.MinecraftEffectTypes.slowFalling, 4, 2, false)
            } else if (mc.world.getDimension(players[p].dimension.id).getBlock(new mc.BlockLocation(Math.floor(players[p].location.x), Math.floor(players[p].location.y), Math.floor(players[p].location.z))).typeId == fluidsIDs[i]) {
                players[p].addEffect(mc.MinecraftEffectTypes.slowFalling, 4, 2, false)
            }
        }
    }
    for (let p = 0; p < players.length; p++) {
        for (let i = 0; i < fluidsIDs.length; i++) {
            if (mc.world.getDimension(players[p].dimension.id).getBlock(new mc.BlockLocation(Math.floor(players[p].location.x), players[p].location.y+1.7, Math.floor(players[p].location.z))).typeId == fluidsIDs[i]) {
                players[p].runCommandAsync("fog @s push fluid:water_fog fluid_fog")
                break
            } else {
                players[p].runCommandAsync("fog @s remove fluid_fog")
            }
        }
    }
})
